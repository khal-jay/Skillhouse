# Visual Canvas Deck (v1.0.1)

Official Skillhouse presentation synthesis workflow package.

## Included Files
- `SKILL.md`: Complete system prompt and agent instruction schema.
- `package.json`: CLI metadata and execution dependencies.

## Installation
```bash
npx @skillhouse/cli install visual-canvas-deck
```
