---
name: visual-canvas-deck
description: Turns rough product briefs and PRDs into editable spatial slide presentations and exportable PPTX decks.
version: 1.0.1
license: MIT
author: Skillhouse Verified
compatibility:
  - Claude Code
  - Cursor
  - OpenAI Codex
---

# Visual Canvas Deck — AI Agent Skill Specification

## Overview
This skill instructs autonomous AI coding agents and design assistants on how to synthesize, structure, and export presentation slide decks from text specifications, PRDs, or unstructured project notes.

## Workflow Phases
1. **Brief Ingestion & Outline Synthesis**:
   - Extract primary thesis, 3 core supporting arguments, and decisive conclusion.
   - Limit presentation to 10-14 high-impact slides.
   - Enforce 60-character maximum line lengths for readability.

2. **Spatial Layout & Composition**:
   - Apply 16:9 widescreen canvas aspect ratio.
   - Enforce 8pt empirical subgrid for cards, margins, and callouts.
   - Restrict color palette to background, surface card, dark ink, and single brand accent.

3. **Export Engine**:
   - Emit valid standalone HTML/CSS presentation deck with keyboard controls (ArrowLeft/ArrowRight).
   - Generate editable PowerPoint (.pptx) file via native OOXML templates.

## CLI Quickstart
```bash
npx @skillhouse/cli install visual-canvas-deck
skillhouse run visual-canvas-deck --input ./PRD.md --output ./presentation.pptx
```
